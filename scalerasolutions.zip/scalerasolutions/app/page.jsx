import Navbar from '../components/Navbar'
import Footer from '../components/Footer'

export default function Home() {
  return (
    <main>
      <Navbar />
      <Hero />
      <MarqueeBar />
      <Services />
      <HowItWorks />
      <Process />
      <Pricing />
      <FAQ />
      <CTA />
      <Footer />
    </main>
  )
}

function Hero() {
  return (
    <section style={{
      minHeight: '100vh',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      textAlign: 'center',
      padding: '8rem 2rem 4rem',
      position: 'relative',
      overflow: 'hidden',
    }}>
      {/* Background grid */}
      <div style={{
        position: 'absolute', inset: 0,
        backgroundImage: 'linear-gradient(rgba(200,245,90,0.04) 1px, transparent 1px), linear-gradient(90deg, rgba(200,245,90,0.04) 1px, transparent 1px)',
        backgroundSize: '60px 60px',
        pointerEvents: 'none',
      }} />

      {/* Glow */}
      <div style={{
        position: 'absolute',
        top: '20%', left: '50%', transform: 'translateX(-50%)',
        width: 600, height: 600,
        background: 'radial-gradient(circle, rgba(200,245,90,0.08) 0%, transparent 70%)',
        pointerEvents: 'none',
      }} />

      <div style={{ position: 'relative', zIndex: 1, maxWidth: 900 }}>
        {/* Badge */}
        <div style={{
          display: 'inline-flex', alignItems: 'center', gap: 8,
          border: '1px solid rgba(200,245,90,0.3)',
          borderRadius: 100,
          padding: '6px 16px',
          marginBottom: '2rem',
          fontSize: 13,
          color: 'var(--accent)',
          fontWeight: 600,
          letterSpacing: '0.05em',
        }}>
          <span className="pulse-dot" style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--accent)', display: 'inline-block' }} />
          AI-Powered Client Acquisition
        </div>

        <h1 style={{
          fontSize: 'clamp(3rem, 8vw, 6.5rem)',
          fontWeight: 800,
          lineHeight: 1.0,
          letterSpacing: '-0.04em',
          marginBottom: '1.5rem',
          color: 'var(--white)',
        }}>
          AI automation<br />
          <span style={{ color: 'var(--accent)' }}>for client</span><br />
          acquisition
        </h1>

        <p style={{
          fontSize: 'clamp(1rem, 2vw, 1.2rem)',
          color: 'rgba(245,245,240,0.55)',
          maxWidth: 560,
          margin: '0 auto 2.5rem',
          lineHeight: 1.7,
        }}>
          Scalera Solutions is all about finding potential clients for you. We replace manual prospecting with a scalable, always-on outbound system.
        </p>

        <div style={{ display: 'flex', gap: '1rem', justifyContent: 'center', flexWrap: 'wrap' }}>
          <a href="https://calendar.app.google/zBaUyZzDHDe2G4oR6" target="_blank" rel="noreferrer"
            style={{
              background: 'var(--accent)',
              color: 'var(--black)',
              padding: '0.9rem 2rem',
              borderRadius: '8px',
              fontWeight: 700,
              fontSize: '15px',
              textDecoration: 'none',
              transition: 'transform 0.2s, opacity 0.2s',
            }}
            onMouseEnter={e => e.currentTarget.style.transform = 'translateY(-2px)'}
            onMouseLeave={e => e.currentTarget.style.transform = 'translateY(0)'}
          >
            Get in touch →
          </a>
          <a href="#services"
            style={{
              border: '1px solid rgba(255,255,255,0.2)',
              color: 'var(--white)',
              padding: '0.9rem 2rem',
              borderRadius: '8px',
              fontWeight: 600,
              fontSize: '15px',
              textDecoration: 'none',
              transition: 'border-color 0.2s',
            }}
            onMouseEnter={e => e.currentTarget.style.borderColor = 'rgba(255,255,255,0.5)'}
            onMouseLeave={e => e.currentTarget.style.borderColor = 'rgba(255,255,255,0.2)'}
          >
            Learn more
          </a>
        </div>
      </div>

      {/* Scroll indicator */}
      <div style={{ position: 'absolute', bottom: '2rem', left: '50%', transform: 'translateX(-50%)', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }}>
        <p style={{ fontSize: 11, color: 'rgba(245,245,240,0.3)', letterSpacing: '0.1em', textTransform: 'uppercase' }}>Scroll</p>
        <div style={{ width: 1, height: 40, background: 'linear-gradient(to bottom, rgba(200,245,90,0.4), transparent)' }} />
      </div>
    </section>
  )
}

function MarqueeBar() {
  const items = ['Lead Generation', 'AI Outreach', 'Client Acquisition', 'Automated Campaigns', 'Sales Pipeline', 'Smart Prospecting', 'Revenue Growth']
  const doubled = [...items, ...items]

  return (
    <div style={{
      borderTop: '1px solid rgba(255,255,255,0.06)',
      borderBottom: '1px solid rgba(255,255,255,0.06)',
      padding: '1rem 0',
      overflow: 'hidden',
      background: 'rgba(255,255,255,0.02)',
    }}>
      <div className="marquee-track" style={{ display: 'flex', gap: '3rem', whiteSpace: 'nowrap', width: 'max-content' }}>
        {doubled.map((item, i) => (
          <span key={i} style={{ fontSize: 13, fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'rgba(245,245,240,0.3)', display: 'flex', alignItems: 'center', gap: '3rem' }}>
            {item}
            <span style={{ color: 'var(--accent)', fontSize: 8 }}>◆</span>
          </span>
        ))}
      </div>
    </div>
  )
}

function Services() {
  return (
    <section id="services" style={{ padding: '6rem 2rem', maxWidth: 1200, margin: '0 auto' }}>
      <div style={{ marginBottom: '4rem' }}>
        <p style={{ color: 'var(--accent)', fontWeight: 700, fontSize: 12, letterSpacing: '0.12em', textTransform: 'uppercase', marginBottom: '1rem' }}>Our service</p>
        <h2 style={{ fontSize: 'clamp(2rem, 5vw, 3.5rem)', fontWeight: 800, letterSpacing: '-0.03em', lineHeight: 1.1, maxWidth: 600 }}>
          Autoclient
        </h2>
        <p style={{ color: 'rgba(245,245,240,0.5)', fontSize: 16, marginTop: '1rem', maxWidth: 500 }}>
          We generate automations that help you close smarter and earn harder.
        </p>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '1.5rem' }}>
        {[
          {
            num: '01',
            title: 'Lead Generation',
            desc: 'Our agents craft prospect lists based on your client profile and buying signals. We find the best contacts from each prospect company.',
            tags: ['Prospect list', 'Buying-signals', 'Contact search'],
          },
          {
            num: '02',
            title: 'Campaign Preparation',
            desc: 'Our agents enrich prospect data, score each lead, and write personalized outreach messages tailored to their specific situation.',
            tags: ['Data enrichment', 'Lead scoring', 'Personalization'],
          },
          {
            num: '03',
            title: 'Campaign Execution',
            desc: 'Automated email scheduling, reply handling, and calendar booking. Your team only clicks send on pre-crafted responses.',
            tags: ['Email automation', 'Reply agent', 'Appointment booking'],
          },
        ].map(card => (
          <div key={card.num} style={{
            border: '1px solid rgba(255,255,255,0.08)',
            borderRadius: 16,
            padding: '2rem',
            background: 'rgba(255,255,255,0.02)',
            transition: 'border-color 0.3s, background 0.3s',
          }}
            onMouseEnter={e => { e.currentTarget.style.borderColor = 'rgba(200,245,90,0.3)'; e.currentTarget.style.background = 'rgba(200,245,90,0.03)' }}
            onMouseLeave={e => { e.currentTarget.style.borderColor = 'rgba(255,255,255,0.08)'; e.currentTarget.style.background = 'rgba(255,255,255,0.02)' }}
          >
            <p style={{ fontFamily: 'monospace', fontSize: 12, color: 'var(--accent)', marginBottom: '1.5rem', fontWeight: 600 }}>{card.num}</p>
            <h3 style={{ fontSize: 22, fontWeight: 700, letterSpacing: '-0.02em', marginBottom: '0.75rem' }}>{card.title}</h3>
            <p style={{ color: 'rgba(245,245,240,0.5)', lineHeight: 1.7, fontSize: 15, marginBottom: '1.5rem' }}>{card.desc}</p>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
              {card.tags.map(tag => (
                <span key={tag} style={{
                  fontSize: 11, fontWeight: 600, letterSpacing: '0.06em',
                  color: 'rgba(245,245,240,0.4)',
                  border: '1px solid rgba(255,255,255,0.1)',
                  borderRadius: 100,
                  padding: '3px 10px',
                }}>{tag}</span>
              ))}
            </div>
          </div>
        ))}
      </div>
    </section>
  )
}

function HowItWorks() {
  return (
    <section style={{ padding: '6rem 2rem', background: 'rgba(255,255,255,0.015)' }}>
      <div style={{ maxWidth: 1200, margin: '0 auto' }}>
        <p style={{ color: 'var(--accent)', fontWeight: 700, fontSize: 12, letterSpacing: '0.12em', textTransform: 'uppercase', marginBottom: '1rem' }}>Introduction</p>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '4rem', alignItems: 'center' }}>
          <div>
            <h2 style={{ fontSize: 'clamp(2rem, 4vw, 3rem)', fontWeight: 800, letterSpacing: '-0.03em', lineHeight: 1.1, marginBottom: '1.5rem' }}>
              The Birth Of Scalera
            </h2>
            <p style={{ color: 'rgba(245,245,240,0.55)', lineHeight: 1.8, fontSize: 16 }}>
              Scalera Solutions was founded to fix a broken process: client acquisition that is slow, manual, and inconsistent. Built by three driven young founders who grew up with tools like AI and the internet.
            </p>
            <p style={{ color: 'rgba(245,245,240,0.55)', lineHeight: 1.8, fontSize: 16, marginTop: '1rem' }}>
              Scalera turns modern technology into a practical growth system for businesses that want results—not experiments.
            </p>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
            {[
              { label: 'Leads processed', value: '100+', sub: 'per campaign' },
              { label: 'Approval rate', value: '90%', sub: 'outreach quality' },
              { label: 'Founders', value: '3', sub: 'young & driven' },
              { label: 'Setup time', value: '<1wk', sub: 'fast onboarding' },
            ].map(stat => (
              <div key={stat.label} style={{
                border: '1px solid rgba(255,255,255,0.08)',
                borderRadius: 12,
                padding: '1.5rem',
                background: 'rgba(255,255,255,0.03)',
              }}>
                <p style={{ fontSize: 32, fontWeight: 800, letterSpacing: '-0.03em', color: 'var(--accent)', lineHeight: 1 }}>{stat.value}</p>
                <p style={{ fontSize: 13, fontWeight: 600, color: 'var(--white)', marginTop: 6 }}>{stat.label}</p>
                <p style={{ fontSize: 11, color: 'rgba(245,245,240,0.35)', marginTop: 2 }}>{stat.sub}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

function Process() {
  const steps = [
    { num: 1, title: 'Contact Us', desc: 'Book an appointment. We present our product and give you a deal tailored to your needs.' },
    { num: 2, title: 'Customization', desc: 'We personalize the automation to fit your style, offer, and ideal client profile.' },
    { num: 3, title: 'Execution', desc: 'The system goes live. Leads are found, qualified, and outreach is initiated on your behalf.' },
    { num: 4, title: 'Feedback', desc: 'We continuously improve based on results. Practice doesn\'t make perfect — feedback does.' },
  ]

  return (
    <section id="process" style={{ padding: '6rem 2rem', maxWidth: 1200, margin: '0 auto' }}>
      <p style={{ color: 'var(--accent)', fontWeight: 700, fontSize: 12, letterSpacing: '0.12em', textTransform: 'uppercase', marginBottom: '1rem' }}>Our Process</p>
      <h2 style={{ fontSize: 'clamp(2rem, 4vw, 3rem)', fontWeight: 800, letterSpacing: '-0.03em', marginBottom: '1rem' }}>
        Simple yet defined
      </h2>
      <p style={{ color: 'rgba(245,245,240,0.5)', maxWidth: 500, marginBottom: '3.5rem', fontSize: 16 }}>
        We design, develop, and implement your client acquisition automation — turning leads into closed deals.
      </p>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '1.5rem' }}>
        {steps.map(step => (
          <div key={step.num} style={{
            border: '1px solid rgba(255,255,255,0.08)',
            borderRadius: 16,
            padding: '2rem',
            position: 'relative',
            background: 'rgba(255,255,255,0.02)',
          }}>
            <div style={{
              width: 40, height: 40,
              border: '1px solid rgba(200,245,90,0.3)',
              borderRadius: 10,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              marginBottom: '1.5rem',
              fontWeight: 800,
              fontSize: 16,
              color: 'var(--accent)',
            }}>{step.num}</div>
            <h3 style={{ fontSize: 20, fontWeight: 700, letterSpacing: '-0.02em', marginBottom: '0.75rem' }}>Step {step.num}: {step.title}</h3>
            <p style={{ color: 'rgba(245,245,240,0.5)', lineHeight: 1.7, fontSize: 15 }}>{step.desc}</p>
          </div>
        ))}
      </div>
    </section>
  )
}

function Pricing() {
  return (
    <section id="pricing" style={{ padding: '6rem 2rem', background: 'rgba(255,255,255,0.015)' }}>
      <div style={{ maxWidth: 900, margin: '0 auto', textAlign: 'center' }}>
        <p style={{ color: 'var(--accent)', fontWeight: 700, fontSize: 12, letterSpacing: '0.12em', textTransform: 'uppercase', marginBottom: '1rem' }}>Pricing</p>
        <h2 style={{ fontSize: 'clamp(2rem, 4vw, 3rem)', fontWeight: 800, letterSpacing: '-0.03em', marginBottom: '1rem' }}>
          We take the risk
        </h2>
        <p style={{ color: 'rgba(245,245,240,0.5)', maxWidth: 480, margin: '0 auto 3.5rem', fontSize: 16 }}>
          Each plan is made personally, but we follow a basic pricing structure based on three pillars.
        </p>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '1.5rem', textAlign: 'left' }}>
          {[
            {
              title: 'Setup fee',
              price: 'From 600€',
              desc: 'Covers our building phase. One-time payment to get your automation up and running.',
              icon: '⚙',
            },
            {
              title: 'Running fee',
              price: '~30€ / 100 leads',
              desc: 'We cover our costs for running the automation. Pay only for what you use.',
              icon: '◎',
              featured: true,
            },
            {
              title: 'Commission',
              price: 'Performance-based',
              desc: 'Our risk, your reward. We get paid via commission on closed deals or booked calls.',
              icon: '✦',
            },
          ].map(tier => (
            <div key={tier.title} style={{
              border: tier.featured ? '1px solid rgba(200,245,90,0.4)' : '1px solid rgba(255,255,255,0.08)',
              borderRadius: 16,
              padding: '2rem',
              background: tier.featured ? 'rgba(200,245,90,0.04)' : 'rgba(255,255,255,0.02)',
              position: 'relative',
            }}>
              {tier.featured && (
                <div style={{
                  position: 'absolute', top: -1, right: 20,
                  background: 'var(--accent)', color: 'var(--black)',
                  fontSize: 10, fontWeight: 800, letterSpacing: '0.08em',
                  padding: '3px 10px', borderRadius: '0 0 8px 8px',
                  textTransform: 'uppercase',
                }}>Most common</div>
              )}
              <div style={{ fontSize: 20, marginBottom: '1rem' }}>{tier.icon}</div>
              <h3 style={{ fontWeight: 700, fontSize: 18, marginBottom: '0.5rem' }}>{tier.title}</h3>
              <p style={{ color: 'var(--accent)', fontWeight: 700, fontSize: 20, marginBottom: '1rem', letterSpacing: '-0.02em' }}>{tier.price}</p>
              <p style={{ color: 'rgba(245,245,240,0.5)', fontSize: 14, lineHeight: 1.7 }}>{tier.desc}</p>
            </div>
          ))}
        </div>

        <div style={{ marginTop: '2.5rem' }}>
          <a href="https://calendar.app.google/zBaUyZzDHDe2G4oR6" target="_blank" rel="noreferrer"
            style={{
              display: 'inline-block',
              background: 'var(--accent)', color: 'var(--black)',
              padding: '1rem 2.5rem', borderRadius: 8,
              fontWeight: 700, fontSize: 15, textDecoration: 'none',
            }}
          >Book a call to get your custom plan</a>
        </div>
      </div>
    </section>
  )
}

function FAQ() {
  return (
    <section style={{ padding: '6rem 2rem', maxWidth: 800, margin: '0 auto' }}>
      <p style={{ color: 'var(--accent)', fontWeight: 700, fontSize: 12, letterSpacing: '0.12em', textTransform: 'uppercase', marginBottom: '1rem' }}>FAQs</p>
      <h2 style={{ fontSize: 'clamp(2rem, 4vw, 3rem)', fontWeight: 800, letterSpacing: '-0.03em', marginBottom: '3rem' }}>
        We've got the answers
      </h2>

      {[
        { q: 'What do I get?', a: 'You get a fully automated client acquisition system — from lead research and outreach to reply handling and appointment booking. We handle the prospecting so you can focus on closing.' },
        { q: 'How do we find leads?', a: 'Our AI agent learns your ideal customer profile, scans the web for matching businesses, and identifies the best contacts. It\'s data-driven, precise, and repeatable.' },
        { q: 'Is this really for me?', a: 'If you\'re a business that wants more clients but doesn\'t want to spend hours on manual outreach, yes. Autoclient is designed for anyone with a clear offer and a desire to grow.' },
        { q: 'What do I need to do?', a: 'Book a call with us, share your ideal client profile, and we handle the rest. Your team just reviews drafts and closes the deals we bring to your inbox.' },
      ].map((item, i) => (
        <details key={i} style={{
          borderBottom: '1px solid rgba(255,255,255,0.08)',
          padding: '1.25rem 0',
          cursor: 'pointer',
        }}>
          <summary style={{
            fontWeight: 700,
            fontSize: 16,
            cursor: 'pointer',
            listStyle: 'none',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            color: 'var(--white)',
          }}>
            {item.q}
            <span style={{ color: 'var(--accent)', fontSize: 20, fontWeight: 300 }}>+</span>
          </summary>
          <p style={{ color: 'rgba(245,245,240,0.55)', marginTop: '1rem', lineHeight: 1.8, fontSize: 15 }}>{item.a}</p>
        </details>
      ))}
    </section>
  )
}

function CTA() {
  return (
    <section style={{ padding: '5rem 2rem', textAlign: 'center', position: 'relative', overflow: 'hidden' }}>
      <div style={{
        position: 'absolute', inset: 0,
        background: 'radial-gradient(ellipse at center, rgba(200,245,90,0.07) 0%, transparent 70%)',
        pointerEvents: 'none',
      }} />
      <div style={{ position: 'relative', zIndex: 1 }}>
        <h2 style={{ fontSize: 'clamp(2rem, 5vw, 3.5rem)', fontWeight: 800, letterSpacing: '-0.03em', lineHeight: 1.1, marginBottom: '1.5rem' }}>
          Let AI find the leads<br />
          <span style={{ color: 'var(--accent)' }}>so you can focus on closing</span>
        </h2>
        <p style={{ color: 'rgba(245,245,240,0.5)', fontSize: 16, marginBottom: '2.5rem' }}>
          Book a call today and join the future of client acquisition.
        </p>
        <a href="https://calendar.app.google/zBaUyZzDHDe2G4oR6" target="_blank" rel="noreferrer"
          style={{
            background: 'var(--accent)', color: 'var(--black)',
            padding: '1.1rem 2.8rem', borderRadius: 8,
            fontWeight: 800, fontSize: 16, textDecoration: 'none',
            display: 'inline-block',
            transition: 'transform 0.2s',
          }}
          onMouseEnter={e => e.currentTarget.style.transform = 'translateY(-3px)'}
          onMouseLeave={e => e.currentTarget.style.transform = 'translateY(0)'}
        >
          Book a call →
        </a>
      </div>
    </section>
  )
}
