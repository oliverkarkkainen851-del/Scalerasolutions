import './globals.css'

export const metadata = {
  title: 'Scalera Solutions — AI Automation for Client Acquisition',
  description: 'Scalera Solutions automates client acquisition using AI. We find, qualify, and reach out to your ideal customers so you can focus on closing.',
}

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}
