'use client'
import { useState, useEffect } from 'react'

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40)
    window.addEventListener('scroll', onScroll)
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  return (
    <nav style={{
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      zIndex: 100,
      padding: '1.2rem 2rem',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      background: scrolled ? 'rgba(10,10,10,0.92)' : 'transparent',
      backdropFilter: scrolled ? 'blur(12px)' : 'none',
      borderBottom: scrolled ? '1px solid rgba(255,255,255,0.07)' : 'none',
      transition: 'all 0.3s ease',
    }}>
      {/* Logo */}
      <a href="/" style={{ display: 'flex', alignItems: 'center', gap: '10px', textDecoration: 'none' }}>
        <div style={{
          width: 32, height: 32,
          background: 'var(--accent)',
          borderRadius: '6px',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
            <path d="M3 9L9 3L15 9L9 15L3 9Z" fill="var(--black)" strokeWidth="0"/>
          </svg>
        </div>
        <span style={{ fontWeight: 700, fontSize: '16px', color: 'var(--white)', letterSpacing: '-0.02em' }}>
          Scalera
        </span>
      </a>

      {/* Desktop links */}
      <div style={{ display: 'flex', gap: '2rem', alignItems: 'center' }} className="hidden-mobile">
        {['Home', 'About', 'Blog', 'Founders'].map(link => (
          <a key={link} href={link === 'Home' ? '/' : `/${link.toLowerCase()}`}
            style={{ color: 'rgba(245,245,240,0.6)', textDecoration: 'none', fontSize: '14px', fontWeight: 500, transition: 'color 0.2s' }}
            onMouseEnter={e => e.target.style.color = 'var(--white)'}
            onMouseLeave={e => e.target.style.color = 'rgba(245,245,240,0.6)'}
          >{link}</a>
        ))}
      </div>

      {/* CTA */}
      <a href="https://calendar.app.google/zBaUyZzDHDe2G4oR6" target="_blank" rel="noreferrer"
        style={{
          background: 'var(--accent)',
          color: 'var(--black)',
          padding: '0.5rem 1.2rem',
          borderRadius: '6px',
          fontWeight: 700,
          fontSize: '14px',
          textDecoration: 'none',
          transition: 'opacity 0.2s',
        }}
        onMouseEnter={e => e.target.style.opacity = '0.85'}
        onMouseLeave={e => e.target.style.opacity = '1'}
      >
        Book a call
      </a>

      <style>{`
        @media (max-width: 768px) {
          .hidden-mobile { display: none !important; }
        }
      `}</style>
    </nav>
  )
}
