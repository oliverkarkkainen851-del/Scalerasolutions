export default function Footer() {
  return (
    <footer style={{
      borderTop: '1px solid rgba(255,255,255,0.08)',
      padding: '3rem 2rem',
      marginTop: '6rem',
    }}>
      <div style={{ maxWidth: 1200, margin: '0 auto', display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '2rem' }}>
        {/* Brand */}
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: '1rem' }}>
            <div style={{ width: 28, height: 28, background: 'var(--accent)', borderRadius: 6, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <svg width="14" height="14" viewBox="0 0 18 18" fill="none">
                <path d="M3 9L9 3L15 9L9 15L3 9Z" fill="var(--black)"/>
              </svg>
            </div>
            <span style={{ fontWeight: 700, color: 'var(--white)' }}>Scalera Solutions</span>
          </div>
          <p style={{ color: 'rgba(245,245,240,0.45)', fontSize: 13, lineHeight: 1.7, maxWidth: 220 }}>
            Autoclient – Automate Smarter, Optimize Faster, and Grow Stronger.
          </p>
          <a href="https://calendar.app.google/zBaUyZzDHDe2G4oR6" target="_blank" rel="noreferrer"
            style={{ display: 'inline-block', marginTop: '1rem', color: 'var(--accent)', fontSize: 13, fontWeight: 600, textDecoration: 'none' }}>
            Book a call →
          </a>
        </div>

        {/* Links */}
        <div>
          <p style={{ fontWeight: 700, fontSize: 13, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'rgba(245,245,240,0.4)', marginBottom: '1rem' }}>Links</p>
          {[['Introduction', '#services'], ['Process', '#process'], ['Pricing', '#pricing']].map(([label, href]) => (
            <a key={label} href={href} style={{ display: 'block', color: 'rgba(245,245,240,0.6)', fontSize: 14, textDecoration: 'none', marginBottom: 8, transition: 'color 0.2s' }}
              onMouseEnter={e => e.target.style.color = 'var(--white)'}
              onMouseLeave={e => e.target.style.color = 'rgba(245,245,240,0.6)'}
            >{label}</a>
          ))}
        </div>

        {/* Pages */}
        <div>
          <p style={{ fontWeight: 700, fontSize: 13, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'rgba(245,245,240,0.4)', marginBottom: '1rem' }}>Pages</p>
          {[['Home', '/'], ['About', '/about'], ['Blog', '/blog'], ['Founders', '/founders']].map(([label, href]) => (
            <a key={label} href={href} style={{ display: 'block', color: 'rgba(245,245,240,0.6)', fontSize: 14, textDecoration: 'none', marginBottom: 8, transition: 'color 0.2s' }}
              onMouseEnter={e => e.target.style.color = 'var(--white)'}
              onMouseLeave={e => e.target.style.color = 'rgba(245,245,240,0.6)'}
            >{label}</a>
          ))}
        </div>
      </div>

      <div style={{ maxWidth: 1200, margin: '2rem auto 0', paddingTop: '1.5rem', borderTop: '1px solid rgba(255,255,255,0.06)', display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap', gap: 8 }}>
        <p style={{ color: 'rgba(245,245,240,0.3)', fontSize: 12 }}>© 2025 Scalera Solutions. All rights reserved.</p>
        <p style={{ color: 'rgba(245,245,240,0.3)', fontSize: 12 }}>Built for growth.</p>
      </div>
    </footer>
  )
}
